import { useEffect, useRef } from 'react'
import type { TaskItem } from '@/data/tasks'
import Thumb from './Thumb'

interface SearchPanelProps {
  searching: boolean
  query: string
  setQuery: (q: string) => void
  results: TaskItem[]
  runningKeys: Set<string>
  highlight: number
  setHighlight: (i: number) => void
  onSelect: (key: string) => void
  onEnter: () => void
}

export default function SearchPanel({
  searching, query, setQuery, results, runningKeys,
  highlight, setHighlight, onSelect, onEnter,
}: SearchPanelProps) {
  const inputRef = useRef<HTMLInputElement>(null)
  const listRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (searching) setTimeout(() => inputRef.current?.focus(), 60)
  }, [searching])

  useEffect(() => {
    listRef.current?.querySelector('[data-hl="1"]')?.scrollIntoView({ block: 'nearest' })
  }, [highlight])

  return (
    <div className="relative" style={{ width: 460 }}>
      {/* 向上拉出的搜索列表 */}
      <div
        className="absolute left-0 right-0 overflow-hidden rounded-2xl border bg-[#14161d]/80 shadow-2xl"
        style={{
          bottom: 'calc(100% + 12px)',
          borderColor: 'rgba(245,179,1,0.28)',
          backdropFilter: 'blur(28px) saturate(150%)',
          WebkitBackdropFilter: 'blur(28px) saturate(150%)',
          boxShadow: '0 24px 64px rgba(0,0,0,0.5), 0 0 40px rgba(245,179,1,0.06), inset 0 1px 0 rgba(255,236,190,0.14)',
          maxHeight: searching ? 340 : 0,
          opacity: searching ? 1 : 0,
          transform: searching ? 'translateY(0)' : 'translateY(24px)',
          transition: 'all 400ms cubic-bezier(0.22, 1, 0.36, 1)',
        }}
      >
        <div ref={listRef} className="max-h-[340px] overflow-y-auto p-2">
          <div className="px-3 py-2 text-[11px] tracking-[0.2em] text-[#f5c542]/60 uppercase flex items-center gap-2">
            <span className="w-1 h-1 rounded-full bg-[#f5b301]" />
            全部窗口 · {results.length}
          </div>
          {results.length === 0 && (
            <div className="px-3 py-6 text-center text-sm text-white/35">没有匹配的窗口</div>
          )}
          {results.map((t, i) => (
            <button
              key={t.key}
              data-hl={i === highlight ? 1 : 0}
              onMouseEnter={() => setHighlight(i)}
              onClick={() => onSelect(t.key)}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-left transition-colors relative ${
                i === highlight ? 'bg-[#f5b301]/12' : 'hover:bg-white/6'
              }`}
            >
              {i === highlight && (
                <span className="absolute left-0 top-1/2 -translate-y-1/2 w-[3px] h-6 rounded-full bg-gradient-to-b from-[#ffe6a3] to-[#f5b301]" />
              )}
              <div className="w-10 h-8 rounded overflow-hidden shrink-0 border border-white/15">
                <Thumb variant={t.variant} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-[13px] text-white/90 truncate">{t.title}</div>
                <div className="text-[11px] text-white/40 flex items-center gap-1.5">
                  {t.appName}
                  {runningKeys.has(t.key) ? (
                    <span className="inline-flex items-center gap-1 text-[#ffd97a]/85">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#f5b301] inline-block" />运行中
                    </span>
                  ) : (
                    <span className="text-white/30">未运行 · 选择以启动</span>
                  )}
                </div>
              </div>
              <kbd
                className="shrink-0 w-6 h-6 rounded-md text-[12px] font-extrabold text-[#3d2c00] flex items-center justify-center border border-[#ffe9b0]/60"
                style={{
                  background: 'linear-gradient(160deg, #ffe6a3, #f5b301 60%, #d99300)',
                  boxShadow: '0 1px 6px rgba(245,179,1,0.4)',
                }}
              >
                {t.key}
              </kbd>
            </button>
          ))}
        </div>
      </div>

      {/* 空格键造型的长条 / 搜索输入框 */}
      <div
        onClick={() => { if (!searching) onEnter() }}
        className={`h-12 rounded-[10px] flex items-center justify-center gap-3 transition-all duration-300 ${searching ? '' : 'cursor-pointer hover:brightness-125'}`}
        style={{
          background: searching
            ? 'linear-gradient(180deg, rgba(255,255,255,0.16), rgba(255,255,255,0.08))'
            : 'linear-gradient(180deg, rgba(255,255,255,0.1), rgba(255,255,255,0.05))',
          border: '1px solid',
          borderColor: searching ? 'rgba(245,179,1,0.65)' : 'rgba(255,255,255,0.2)',
          // 键帽手感:底部一条金色"棱线"
          boxShadow: searching
            ? '0 8px 32px rgba(0,0,0,0.45), 0 0 28px rgba(245,179,1,0.22), inset 0 1px 0 rgba(255,255,255,0.3), inset 0 -3px 0 rgba(245,179,1,0.55)'
            : '0 4px 16px rgba(0,0,0,0.3), inset 0 1px 0 rgba(255,255,255,0.18), inset 0 -3px 0 rgba(245,179,1,0.35)',
          backdropFilter: 'blur(18px)',
          WebkitBackdropFilter: 'blur(18px)',
        }}
      >
        {searching ? (
          <>
            <svg className="w-4 h-4 text-[#f5c542]/80 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <circle cx="11" cy="11" r="7" /><path d="m21 21-4.3-4.3" strokeLinecap="round" />
            </svg>
            <input
              ref={inputRef}
              value={query}
              onChange={(e) => { setQuery(e.target.value); setHighlight(0) }}
              placeholder="输入窗口标题或应用名…"
              className="flex-1 bg-transparent outline-none text-[15px] text-white placeholder-white/35"
            />
            <kbd className="shrink-0 text-[10px] text-[#ffd97a]/70 border border-[#f5b301]/35 rounded px-1.5 py-0.5">Esc 退出</kbd>
          </>
        ) : (
          <span className="text-[14px] text-white/75 tracking-[0.25em] select-none flex items-center gap-3">
            <span className="w-4 h-px bg-[#f5b301]/60" />
            按下空格搜索
            <span className="w-4 h-px bg-[#f5b301]/60" />
          </span>
        )}
      </div>
    </div>
  )
}
