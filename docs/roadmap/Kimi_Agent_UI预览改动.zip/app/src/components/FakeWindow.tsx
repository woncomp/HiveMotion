import type { TaskItem } from '@/data/tasks'
import Thumb from './Thumb'

interface FakeWindowProps {
  task: TaskItem
  active: boolean
  zIndex: number
  cascade: number   // 层叠偏移档位
  isNew: boolean    // 刚被召唤,播放入场动画
  onFocus: (key: string) => void
  onClose: (key: string) => void
}

export default function FakeWindow({ task, active, zIndex, cascade, isNew, onFocus, onClose }: FakeWindowProps) {
  const w = Math.min(760, window.innerWidth * 0.62)
  const h = Math.min(500, window.innerHeight * 0.62)
  const off = (cascade % 6) * 28

  return (
    <div
      className="absolute rounded-xl overflow-hidden select-none"
      style={{
        width: w, height: h,
        left: `calc(50% - ${w / 2}px + ${off - 70}px)`,
        top: `calc(50% - ${h / 2}px + ${off - 60}px)`,
        zIndex,
        boxShadow: active
          ? '0 32px 90px rgba(0,0,0,0.55), 0 0 0 1px rgba(255,255,255,0.12)'
          : '0 16px 48px rgba(0,0,0,0.4), 0 0 0 1px rgba(255,255,255,0.07)',
        filter: active ? 'none' : 'brightness(0.72) saturate(0.85)',
        transition: 'filter 300ms, box-shadow 300ms',
        animation: isNew ? 'windowIn 480ms cubic-bezier(0.22, 1, 0.36, 1)' : undefined,
      }}
      onMouseDown={() => onFocus(task.key)}
    >
      {/* 标题栏 */}
      <div className="h-10 flex items-center px-3 gap-2 bg-[#2b2f38]/95 backdrop-blur border-b border-white/10 relative">
        {active && (
          <div className="absolute top-0 left-0 right-0 h-[2px]" style={{ background: 'linear-gradient(90deg, transparent, #f5b301 30%, #ffe6a3 50%, #f5b301 70%, transparent)' }} />
        )}
        <div
          className="w-5 h-5 rounded flex items-center justify-center text-[11px] font-bold text-white shrink-0"
          style={{ background: task.accent }}
        >
          {task.key}
        </div>
        <span className="text-[13px] text-white/85 truncate flex-1">{task.title}</span>
        <div className="flex items-center gap-1 shrink-0">
          <button className="w-8 h-6 rounded hover:bg-white/10 flex items-center justify-center text-white/60">
            <svg width="10" height="10" viewBox="0 0 10 10"><path d="M1 5h8" stroke="currentColor" strokeWidth="1.2" /></svg>
          </button>
          <button className="w-8 h-6 rounded hover:bg-white/10 flex items-center justify-center text-white/60">
            <svg width="9" height="9" viewBox="0 0 9 9"><rect x="0.8" y="0.8" width="7.4" height="7.4" fill="none" stroke="currentColor" strokeWidth="1.2" /></svg>
          </button>
          <button
            className="w-8 h-6 rounded hover:bg-[#e81123] flex items-center justify-center text-white/60 hover:text-white transition-colors"
            onClick={(e) => { e.stopPropagation(); onClose(task.key) }}
          >
            <svg width="10" height="10" viewBox="0 0 10 10"><path d="M1 1l8 8M9 1l-8 8" stroke="currentColor" strokeWidth="1.2" /></svg>
          </button>
        </div>
      </div>
      {/* 内容 */}
      <div className="bg-[#1b1f27]" style={{ height: 'calc(100% - 40px)' }}>
        <Thumb variant={task.variant} />
      </div>
    </div>
  )
}
