import {
  KEY_ROWS, HEX_W, HEX_H, PITCH_X,
  GRID_W, GRID_H, cellCenter, CUT_X,
  type TaskItem,
} from '@/data/tasks'
import Thumb from './Thumb'

/** 正六边形(尖顶):宽 = 高 × √3/2 */
const HEX_CLIP = 'polygon(50% 0%, 100% 25%, 100% 75%, 50% 100%, 0% 75%, 0% 25%)'

interface HexProps {
  task: TaskItem
  row: number
  col: number
  searching: boolean
  onSelect: (key: string) => void
}

function Hex({ task, row, col, searching, onSelect }: HexProps) {
  const { x, y } = cellCenter(row, col)
  const left = x - HEX_W / 2
  const top = y - HEX_H / 2
  const isLeftSide = x < CUT_X
  const distFromCut = Math.abs(x - CUT_X) / PITCH_X
  // 搜索激活时向两侧避让,按距离切割线的远近做级联延迟
  const shift = searching ? (isLeftSide ? -1 : 1) * (PITCH_X * 2.6) : 0
  const delay = searching ? distFromCut * 40 : (4 - Math.min(distFromCut, 4)) * 40

  return (
    <div
      className="absolute cursor-pointer group"
      style={{
        left, top, width: HEX_W, height: HEX_H,
        transform: `translateX(${shift}px) scale(${searching ? 0.92 : 1})`,
        opacity: searching ? 0.6 : 1,
        transitionProperty: 'transform, opacity, filter',
        transitionDuration: '420ms',
        transitionTimingFunction: 'cubic-bezier(0.22, 1, 0.36, 1)',
        transitionDelay: `${delay}ms`,
        filter: 'drop-shadow(0 10px 22px rgba(0,0,0,0.5))',
        zIndex: 1,
      }}
      onClick={() => onSelect(task.key)}
    >
      {/* 蜂蜜金渐变描边层 */}
      <div
        className="absolute inset-0 transition-all duration-300 group-hover:scale-[1.06]"
        style={{
          clipPath: HEX_CLIP,
          background:
            'linear-gradient(165deg, rgba(255,236,190,0.95) 0%, rgba(245,179,1,0.75) 38%, rgba(140,100,10,0.55) 72%, rgba(255,214,120,0.85) 100%)',
        }}
      >
        {/* 液态玻璃内层 */}
        <div
          className="absolute overflow-hidden"
          style={{
            clipPath: HEX_CLIP,
            inset: 1.5,
            background: 'linear-gradient(180deg, rgba(30,32,40,0.72), rgba(16,18,24,0.82))',
            backdropFilter: 'blur(14px) saturate(140%)',
            WebkitBackdropFilter: 'blur(14px) saturate(140%)',
          }}
        >
          {/* 缩略图 */}
          <div className="absolute inset-[6%] opacity-90 brightness-[0.8] transition-all duration-300 group-hover:scale-110 group-hover:opacity-100 group-hover:brightness-[0.9]">
            <Thumb variant={task.variant} />
          </div>
          {/* 玻璃高光 + 底部压暗,保证文字可读 */}
          <div className="absolute inset-0 bg-gradient-to-b from-white/14 via-black/10 to-black/75 pointer-events-none" />
          <div
            className="absolute inset-x-[18%] top-[6%] h-[26%] pointer-events-none opacity-60"
            style={{ background: 'radial-gradient(60% 100% at 50% 0%, rgba(255,255,255,0.22), transparent 70%)' }}
          />
          {/* 蜂蜜滴键帽 */}
          <div
            className="absolute top-[8%] left-1/2 -translate-x-1/2 min-w-[27px] h-[27px] px-1.5 rounded-lg flex items-center justify-center text-[13px] font-extrabold text-[#3d2c00] border border-[#ffe9b0]/70 transition-transform duration-300 group-hover:scale-110"
            style={{
              background: 'linear-gradient(160deg, #ffe6a3 0%, #f5b301 55%, #d99300 100%)',
              boxShadow: '0 2px 10px rgba(245,179,1,0.55), inset 0 1px 0 rgba(255,255,255,0.75)',
            }}
          >
            {task.key}
          </div>
          {/* 标题(截断) */}
          <div className="absolute bottom-[9%] left-[16%] right-[16%] text-center">
            <div className="text-[11px] leading-tight text-white/95 truncate drop-shadow">
              {task.title}
            </div>
            <div className="text-[9px] text-[#f5c542]/80 truncate tracking-wide">{task.appName}</div>
          </div>
        </div>
      </div>
    </div>
  )
}

interface HiveProps {
  running: TaskItem[]
  searching: boolean
  scale: number
  onSelect: (key: string) => void
}

export default function Hive({ running, searching, scale, onSelect }: HiveProps) {
  const byKey = new Map(running.map((t) => [t.key, t]))

  return (
    <div
      className="relative shrink-0"
      style={{ width: GRID_W * scale, height: GRID_H * scale }}
    >
      <div
        className="absolute left-0 top-0 origin-top-left"
        style={{ width: GRID_W, height: GRID_H, transform: `scale(${scale})` }}
      >
        {KEY_ROWS.map((rowKeys, row) =>
          rowKeys.map((k, col) => {
            const task = byKey.get(k)
            if (!task) return null // 空格子隐藏
            return (
              <Hex
                key={k}
                task={task}
                row={row}
                col={col}
                searching={searching}
                onSelect={onSelect}
              />
            )
          })
        )}
      </div>
    </div>
  )
}
