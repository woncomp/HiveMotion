import type { ThumbVariant } from '@/data/tasks'

/**
 * 纯 CSS 绘制的假窗口内容,用于六边形缩略图和桌面假窗口。
 * 所有元素使用百分比/flex 布局,自适应任意容器尺寸。
 */

const Line = ({ w, c = '#c9ccd3', h = 6 }: { w: string; c?: string; h?: number }) => (
  <div style={{ width: w, height: h, borderRadius: h / 2, background: c }} />
)

function Notepad() {
  return (
    <div className="w-full h-full bg-[#fdfdfd] p-[8%] flex flex-col gap-[6%]">
      {['92%', '100%', '78%', '95%', '60%', '88%', '40%'].map((w, i) => (
        <Line key={i} w={w} c={i === 3 ? '#5b9bd5' : '#d7dae0'} />
      ))}
      <div className="w-[2px] h-[8%] bg-[#5b9bd5] animate-pulse" />
    </div>
  )
}

function Explorer() {
  const folders = ['项目', '图片', '文档', '下载', '音乐', '桌面']
  return (
    <div className="w-full h-full bg-[#f7f7f8] flex flex-col">
      <div className="h-[16%] bg-[#ececee] flex items-center px-[6%] gap-[4%]">
        <div className="w-[14%] h-[55%] rounded-full bg-white border border-[#d5d5d9]" />
        <div className="flex-1 h-[55%] rounded bg-white border border-[#d5d5d9]" />
      </div>
      <div className="flex-1 grid grid-cols-3 gap-[6%] p-[6%] content-start">
        {folders.map((f) => (
          <div key={f} className="flex flex-col items-center gap-1">
            <div className="w-[70%] aspect-[1.25] rounded-[3px] bg-[#f2c94c] relative overflow-hidden">
              <div className="absolute top-0 left-0 w-[45%] h-[22%] bg-[#e0b53e] rounded-t-[3px]" />
            </div>
            <span className="text-[9px] text-[#555] leading-none">{f}</span>
          </div>
        ))}
      </div>
    </div>
  )
}

function Browser() {
  return (
    <div className="w-full h-full bg-white flex flex-col">
      <div className="h-[14%] bg-[#e8eaee] flex items-center px-[5%] gap-[3%]">
        <div className="w-[6%] aspect-square rounded-full bg-[#c4c8d0]" />
        <div className="w-[6%] aspect-square rounded-full bg-[#c4c8d0]" />
        <div className="flex-1 h-[60%] rounded-full bg-white border border-[#d8dbe1]" />
      </div>
      <div className="flex-1 p-[6%] flex flex-col gap-[7%]">
        <div className="h-[28%] rounded bg-gradient-to-r from-[#4caf7d]/30 to-[#2f80ed]/30" />
        <div className="flex gap-[5%] flex-1">
          <div className="flex-1 flex flex-col gap-[10%]">
            <Line w="90%" c="#d7dae0" /><Line w="100%" c="#e2e4e9" /><Line w="70%" c="#e2e4e9" />
          </div>
          <div className="w-[32%] rounded bg-[#eef0f4]" />
        </div>
      </div>
    </div>
  )
}

function Code() {
  const rows: [string, string][] = [
    ['30%', '#c586c0'], ['55%', '#9cdcfe'], ['42%', '#ce9178'], ['70%', '#4ec9b0'],
    ['35%', '#dcdcaa'], ['62%', '#9cdcfe'], ['48%', '#ce9178'], ['25%', '#6a9955'],
  ]
  return (
    <div className="w-full h-full bg-[#1e1e1e] flex">
      <div className="w-[16%] bg-[#252526] p-[6%] flex flex-col gap-[12%]">
        {['80%', '65%', '90%', '50%'].map((w, i) => <Line key={i} w={w} c="#3a3d41" h={5} />)}
      </div>
      <div className="flex-1 p-[5%] flex flex-col justify-center gap-[7%]">
        {rows.map(([w, c], i) => (
          <div key={i} className="flex gap-[6%]" style={{ paddingLeft: i % 3 === 1 ? '10%' : 0 }}>
            <Line w="8%" c="#3a3d41" h={5} /><Line w={w} c={c} h={5} />
          </div>
        ))}
      </div>
    </div>
  )
}

function Terminal() {
  return (
    <div className="w-full h-full bg-[#0c0c0c] p-[7%] flex flex-col justify-center gap-[9%]">
      <div className="flex gap-[4%] items-center"><Line w="22%" c="#16c60c" h={5} /><Line w="45%" c="#cccccc" h={5} /></div>
      <div className="flex gap-[4%] items-center"><Line w="22%" c="#16c60c" h={5} /><Line w="60%" c="#8a8a8a" h={5} /></div>
      <div className="flex gap-[4%] items-center"><Line w="22%" c="#16c60c" h={5} /><Line w="30%" c="#3b78ff" h={5} /></div>
      <div className="flex gap-[4%] items-center"><Line w="22%" c="#16c60c" h={5} /><div className="w-[3%] h-[8px] bg-[#cccccc] animate-pulse" /></div>
    </div>
  )
}

function Mail() {
  return (
    <div className="w-full h-full bg-white flex">
      <div className="w-[34%] border-r border-[#ececf0] flex flex-col">
        {[0, 1, 2, 3].map((i) => (
          <div key={i} className={`flex-1 px-[8%] flex flex-col justify-center gap-[14%] ${i === 0 ? 'bg-[#e8f1fd]' : ''}`}>
            <Line w="70%" c={i === 0 ? '#2f80ed' : '#c9ccd3'} h={5} /><Line w="90%" c="#e2e4e9" h={4} />
          </div>
        ))}
      </div>
      <div className="flex-1 p-[7%] flex flex-col gap-[8%]">
        <Line w="55%" c="#9aa0a6" h={7} />
        <Line w="100%" c="#e2e4e9" /><Line w="95%" c="#e2e4e9" /><Line w="80%" c="#e2e4e9" /><Line w="60%" c="#ececf0" />
      </div>
    </div>
  )
}

function Paint() {
  return (
    <div className="w-full h-full bg-[#f0f0f2] flex flex-col">
      <div className="h-[18%] bg-[#fafafc] border-b border-[#e0e0e4] flex items-center px-[4%] gap-[3%]">
        {['#e06c9f', '#f2c94c', '#4caf7d', '#2f80ed', '#bb6bd9'].map((c) => (
          <div key={c} className="w-[5%] aspect-square rounded-full" style={{ background: c }} />
        ))}
      </div>
      <div className="flex-1 m-[5%] bg-white border border-[#dcdce0] relative overflow-hidden">
        <div className="absolute w-[34%] aspect-square rounded-full bg-[#e06c9f]/70" style={{ left: '12%', top: '18%' }} />
        <div className="absolute w-[30%] aspect-[1.4] bg-[#2f80ed]/60 rounded" style={{ right: '12%', bottom: '16%' }} />
        <div className="absolute w-[26%] aspect-square bg-[#f2c94c]/70" style={{ left: '42%', top: '30%', transform: 'rotate(24deg)' }} />
      </div>
    </div>
  )
}

function Settings() {
  return (
    <div className="w-full h-full bg-[#f3f3f6] p-[7%] flex flex-col gap-[7%]">
      <Line w="45%" c="#8a8f9a" h={8} />
      {[0, 1, 2, 3].map((i) => (
        <div key={i} className="flex items-center justify-between bg-white rounded px-[5%] py-[3%]">
          <div className="flex flex-col gap-[4px] w-[60%]"><Line w="70%" c="#c9ccd3" h={5} /><Line w="45%" c="#e2e4e9" h={4} /></div>
          <div className={`w-[14%] h-[10px] rounded-full relative ${i % 2 === 0 ? 'bg-[#7c83fd]' : 'bg-[#d5d5d9]'}`}>
            <div className={`absolute top-[1px] w-[8px] h-[8px] rounded-full bg-white ${i % 2 === 0 ? 'right-[1px]' : 'left-[1px]'}`} />
          </div>
        </div>
      ))}
    </div>
  )
}

function Video() {
  return (
    <div className="w-full h-full bg-[#141414] relative flex items-center justify-center">
      <div className="absolute inset-0 bg-gradient-to-br from-[#bb6bd9]/40 via-transparent to-[#2f80ed]/30" />
      <div className="w-[16%] aspect-square rounded-full bg-white/90 flex items-center justify-center">
        <div className="w-0 h-0 border-y-[8px] border-y-transparent border-l-[14px] border-l-[#141414] ml-[6%]" />
      </div>
      <div className="absolute bottom-[6%] left-[6%] right-[6%] h-[4px] rounded bg-white/25">
        <div className="h-full w-[42%] rounded bg-[#bb6bd9]" />
      </div>
    </div>
  )
}

function Music() {
  return (
    <div className="w-full h-full bg-gradient-to-br from-[#2d1b4e] to-[#f2994a]/60 flex items-center gap-[8%] px-[8%]">
      <div className="w-[30%] aspect-square rounded-full bg-[#1a1a1a] border-[3px] border-[#f2994a] relative">
        <div className="absolute inset-[38%] rounded-full bg-[#f2994a]" />
      </div>
      <div className="flex-1 flex flex-col gap-[10%]">
        <Line w="70%" c="#ffffff" h={7} /><Line w="45%" c="#ffffff88" h={5} />
        <div className="flex items-end gap-[6%] h-[26%]">
          {[40, 75, 55, 90, 60, 80, 35].map((h, i) => (
            <div key={i} className="flex-1 rounded-t bg-[#f2994a]" style={{ height: `${h}%` }} />
          ))}
        </div>
      </div>
    </div>
  )
}

function Calc() {
  return (
    <div className="w-full h-full bg-[#202020] p-[6%] flex flex-col gap-[5%]">
      <div className="h-[22%] flex flex-col items-end justify-center gap-[6%] px-[4%]">
        <Line w="30%" c="#6d6d6d" h={5} /><Line w="45%" c="#ffffff" h={10} />
      </div>
      <div className="flex-1 grid grid-cols-4 gap-[3%]">
        {Array.from({ length: 16 }).map((_, i) => (
          <div key={i} className={`rounded ${[3, 7, 11, 15].includes(i) ? 'bg-[#56ccf2]/70' : 'bg-[#323232]'}`} />
        ))}
      </div>
    </div>
  )
}

function Doc() {
  return (
    <div className="w-full h-full bg-[#e8eaee] flex flex-col">
      <div className="h-[16%] bg-[#2b579a] flex items-center px-[5%] gap-[3%]">
        {[0, 1, 2, 3, 4].map((i) => <Line key={i} w="9%" c="#ffffff55" h={5} />)}
      </div>
      <div className="flex-1 flex items-center justify-center">
        <div className="w-[70%] h-[86%] bg-white shadow flex flex-col p-[8%] gap-[6%]">
          <Line w="60%" c="#2b579a" h={7} />
          {['100%', '95%', '100%', '82%', '100%', '55%'].map((w, i) => <Line key={i} w={w} c="#dfe2e8" />)}
        </div>
      </div>
    </div>
  )
}

function Sheet() {
  return (
    <div className="w-full h-full bg-white flex flex-col">
      <div className="h-[15%] bg-[#217346] flex items-center px-[4%]"><Line w="40%" c="#ffffff66" h={5} /></div>
      <div className="flex-1 grid grid-cols-5 grid-rows-6">
        {Array.from({ length: 30 }).map((_, i) => (
          <div key={i} className={`border-[0.5px] border-[#e2e4e9] ${i < 5 ? 'bg-[#217346]/20' : i % 7 === 0 ? 'bg-[#217346]/10' : ''}`} />
        ))}
      </div>
    </div>
  )
}

function Chat() {
  return (
    <div className="w-full h-full bg-[#f2f4f7] p-[7%] flex flex-col justify-center gap-[8%]">
      <div className="flex gap-[4%] items-end">
        <div className="w-[8%] aspect-square rounded-full bg-[#27ae60]" />
        <div className="w-[52%] h-[14px] rounded-lg rounded-bl-none bg-white shadow-sm" />
      </div>
      <div className="flex gap-[4%] items-end">
        <div className="w-[8%] aspect-square rounded-full bg-[#f2994a]" />
        <div className="w-[40%] h-[14px] rounded-lg rounded-bl-none bg-white shadow-sm" />
      </div>
      <div className="flex gap-[4%] items-end justify-end">
        <div className="w-[46%] h-[14px] rounded-lg rounded-br-none bg-[#95ec69]" />
        <div className="w-[8%] aspect-square rounded-full bg-[#2f80ed]" />
      </div>
      <div className="flex gap-[4%] items-end">
        <div className="w-[8%] aspect-square rounded-full bg-[#bb6bd9]" />
        <div className="w-[58%] h-[14px] rounded-lg rounded-bl-none bg-white shadow-sm" />
      </div>
    </div>
  )
}

const VARIANTS: Record<ThumbVariant, () => React.ReactElement> = {
  notepad: Notepad, explorer: Explorer, browser: Browser, code: Code, terminal: Terminal,
  mail: Mail, paint: Paint, settings: Settings, video: Video, music: Music,
  calc: Calc, doc: Doc, sheet: Sheet, chat: Chat,
}

export default function Thumb({ variant }: { variant: ThumbVariant }) {
  const Comp = VARIANTS[variant]
  return (
    <div className="w-full h-full overflow-hidden">
      <Comp />
    </div>
  )
}
