import { useEffect, useState } from 'react'
import type { TaskItem } from '@/data/tasks'

interface DesktopProps {
  running: TaskItem[]
  openKeys: string[]
  activeKey: string | null
  onTaskbarClick: (key: string) => void
}

function Clock() {
  const [now, setNow] = useState(new Date())
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(t)
  }, [])
  const pad = (n: number) => String(n).padStart(2, '0')
  return (
    <div className="text-right leading-tight">
      <div className="text-[12px] text-white/90">{pad(now.getHours())}:{pad(now.getMinutes())}</div>
      <div className="text-[11px] text-white/60">{now.getFullYear()}/{pad(now.getMonth() + 1)}/{pad(now.getDate())}</div>
    </div>
  )
}

export default function Desktop({ running, openKeys, activeKey, onTaskbarClick }: DesktopProps) {
  return (
    <div className="absolute inset-0 overflow-hidden">
      {/* 壁纸:Win11 Bloom 风格渐变 */}
      <div
        className="absolute inset-0"
        style={{
          background:
            'radial-gradient(120% 90% at 18% 8%, #3a6ea8 0%, transparent 55%),' +
            'radial-gradient(110% 100% at 85% 20%, #6a4c93 0%, transparent 60%),' +
            'radial-gradient(120% 110% at 70% 95%, #1b3a5c 0%, transparent 60%),' +
            'linear-gradient(150deg, #16283e 0%, #1e2a4a 45%, #241f3d 100%)',
        }}
      />
      <div
        className="absolute inset-0 opacity-40"
        style={{
          background:
            'radial-gradient(45% 35% at 30% 40%, rgba(120,180,255,0.25), transparent 70%),' +
            'radial-gradient(40% 40% at 68% 55%, rgba(200,140,255,0.2), transparent 70%)',
        }}
      />

      {/* 桌面图标 */}
      <div className="absolute left-5 top-5 flex flex-col gap-6">
        {[
          { name: '此电脑', icon: '🖥️' },
          { name: '回收站', icon: '🗑️' },
          { name: '丰巢演示', icon: '🐝' },
        ].map((d) => (
          <div key={d.name} className="w-20 flex flex-col items-center gap-1.5 cursor-default rounded p-1.5 hover:bg-white/10 transition-colors">
            <div className="w-10 h-10 rounded-lg bg-white/10 border border-white/15 backdrop-blur flex items-center justify-center text-xl shadow">
              {d.icon}
            </div>
            <span className="text-[12px] text-white/90 drop-shadow">{d.name}</span>
          </div>
        ))}
      </div>

      {/* 任务栏 */}
      <div
        className="absolute left-0 right-0 bottom-0 h-12 flex items-center px-3"
        style={{
          background: 'rgba(24, 28, 38, 0.72)',
          backdropFilter: 'blur(28px) saturate(160%)',
          borderTop: '1px solid rgba(255,255,255,0.09)',
        }}
      >
        <div className="flex-1" />
        <div className="flex items-center gap-1.5">
          {/* 开始按钮 */}
          <button className="w-10 h-9 rounded-md hover:bg-white/10 flex items-center justify-center transition-colors">
            <svg width="17" height="17" viewBox="0 0 24 24">
              <rect x="2" y="2" width="9.5" height="9.5" rx="1" fill="#4cc2ff" />
              <rect x="12.5" y="2" width="9.5" height="9.5" rx="1" fill="#7fd4ff" />
              <rect x="2" y="12.5" width="9.5" height="9.5" rx="1" fill="#2aa4e8" />
              <rect x="12.5" y="12.5" width="9.5" height="9.5" rx="1" fill="#4cc2ff" />
            </svg>
          </button>
          {running.map((t) => {
            const isOpen = openKeys.includes(t.key)
            const isActive = activeKey === t.key
            return (
              <button
                key={t.key}
                onClick={() => onTaskbarClick(t.key)}
                className={`relative w-10 h-9 rounded-md flex items-center justify-center transition-colors ${
                  isActive ? 'bg-white/15' : 'hover:bg-white/10'
                }`}
                title={t.title}
              >
                <div
                  className="w-6 h-6 rounded flex items-center justify-center text-[12px] font-bold text-white"
                  style={{ background: t.accent }}
                >
                  {t.key}
                </div>
                {isOpen && (
                  <div
                    className={`absolute bottom-0.5 rounded-full transition-all ${
                      isActive ? 'w-4 h-[3px]' : 'w-1.5 h-[3px] bg-white/45'
                    }`}
                    style={isActive ? {
                      background: 'linear-gradient(90deg, #ffe6a3, #f5b301)',
                      boxShadow: '0 0 6px rgba(245,179,1,0.7)',
                    } : undefined}
                  />
                )}
              </button>
            )
          })}
        </div>
        <div className="flex-1 flex justify-end items-center gap-3 pr-1">
          <svg className="w-4 h-4 text-white/70" viewBox="0 0 24 24" fill="currentColor">
            <path d="M12 3C7 3 3 7 3 12s4 9 9 9 9-4 9-9" fill="none" stroke="currentColor" strokeWidth="2" />
            <path d="M12 7v5l3 3" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
          <Clock />
        </div>
      </div>
    </div>
  )
}
