import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { TASK_POOL, GRID_W, GRID_H, type TaskItem } from '@/data/tasks'
import Desktop from '@/components/Desktop'
import FakeWindow from '@/components/FakeWindow'
import Hive from '@/components/Hive'
import SearchPanel from '@/components/SearchPanel'

interface OpenWin {
  key: string
  z: number
  isNew: boolean
}

/** 随机抽取一部分任务作为"正在运行的窗口" */
function pickRunning(): TaskItem[] {
  const shuffled = [...TASK_POOL].sort(() => Math.random() - 0.5)
  const count = 8 + Math.floor(Math.random() * 4) // 8~11 个
  return shuffled.slice(0, count)
}

export default function Home() {
  const [overlayOpen, setOverlayOpen] = useState(false)
  const [searching, setSearching] = useState(false)
  const [query, setQuery] = useState('')
  const [highlight, setHighlight] = useState(0)
  const [running, setRunning] = useState<TaskItem[]>(() => pickRunning())
  const [windows, setWindows] = useState<OpenWin[]>([])
  const [activeKey, setActiveKey] = useState<string | null>(null)
  const zCounter = useRef(1)
  const [viewport, setViewport] = useState({ w: window.innerWidth, h: window.innerHeight })

  useEffect(() => {
    const onResize = () => setViewport({ w: window.innerWidth, h: window.innerHeight })
    window.addEventListener('resize', onResize)
    return () => window.removeEventListener('resize', onResize)
  }, [])

  const runningKeys = useMemo(() => new Set(running.map((t) => t.key)), [running])
  const taskByKey = useMemo(() => new Map(TASK_POOL.map((t) => [t.key, t])), [])

  /** 召唤/聚焦一个窗口(模拟"跳转到这个进程") */
  const summon = useCallback((key: string) => {
    const z = ++zCounter.current
    setWindows((ws) => {
      const exist = ws.find((w) => w.key === key)
      if (exist) return ws.map((w) => (w.key === key ? { ...w, z, isNew: false } : { ...w, isNew: false }))
      return [...ws.map((w) => ({ ...w, isNew: false })), { key, z, isNew: true }]
    })
    setActiveKey(key)
  }, [])

  const closeWindow = useCallback((key: string) => {
    setWindows((ws) => ws.filter((w) => w.key !== key))
    setActiveKey((cur) => (cur === key ? null : cur))
  }, [])

  /** 唤起任务一览:无任何动画,立即显示,追求响应速度 */
  const openOverlay = useCallback(() => {
    setRunning(pickRunning()) // 每次激活随机填充格子
    setSearching(false)
    setQuery('')
    setHighlight(0)
    setOverlayOpen(true)
  }, [])

  const closeOverlay = useCallback(() => {
    setSearching(false)
    setOverlayOpen(false)
  }, [])

  /** 在任务一览中选中某个格子 → 立即关闭一览,回到桌面并呼出窗口 */
  const switchTo = useCallback((key: string) => {
    closeOverlay()
    summon(key)
  }, [closeOverlay, summon])

  const enterSearch = useCallback(() => {
    setSearching(true)
    setQuery('')
    setHighlight(0)
  }, [])

  const exitSearch = useCallback(() => {
    setSearching(false)
    setQuery('')
    setHighlight(0)
  }, [])

  const results = useMemo(() => {
    const q = query.trim().toLowerCase()
    // 运行中的排前面,未运行的(模拟启动)排后面
    const sorted = [...TASK_POOL].sort((a, b) => {
      const ra = runningKeys.has(a.key) ? 0 : 1
      const rb = runningKeys.has(b.key) ? 0 : 1
      return ra - rb
    })
    if (!q) return sorted
    return sorted.filter(
      (t) =>
        t.title.toLowerCase().includes(q) ||
        t.appName.toLowerCase().includes(q) ||
        t.key.toLowerCase() === q
    )
  }, [query, runningKeys])

  // 全局键盘模拟
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!overlayOpen) return
      if (searching) {
        if (e.key === 'Escape') { e.preventDefault(); exitSearch() }
        else if (e.key === 'ArrowDown') { e.preventDefault(); setHighlight((h) => Math.min(h + 1, results.length - 1)) }
        else if (e.key === 'ArrowUp') { e.preventDefault(); setHighlight((h) => Math.max(h - 1, 0)) }
        else if (e.key === 'Enter') { e.preventDefault(); if (results[highlight]) switchTo(results[highlight].key) }
        return
      }
      if (e.key === 'Escape') { e.preventDefault(); closeOverlay() }
      else if (e.key === ' ') { e.preventDefault(); enterSearch() }
      else if (/^[a-zA-Z]$/.test(e.key)) {
        const k = e.key.toUpperCase()
        if (runningKeys.has(k)) switchTo(k)
      }
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [overlayOpen, searching, results, highlight, runningKeys, closeOverlay, enterSearch, exitSearch, switchTo])

  // 蜂巢缩放:适配视口
  const hiveScale = Math.min(
    1,
    (viewport.w * 0.92) / GRID_W,
    (viewport.h * 0.52) / GRID_H
  )

  return (
    <div className="fixed inset-0 overflow-hidden bg-black font-['Segoe_UI','Microsoft_YaHei',sans-serif]">
      {/* ===== 模拟桌面 ===== */}
      <Desktop
        running={running}
        openKeys={windows.map((w) => w.key)}
        activeKey={activeKey}
        onTaskbarClick={summon}
      />

      {/* 桌面上的假窗口层 */}
      <div className="absolute inset-0 bottom-12">
        {windows.map((w) => {
          const task = taskByKey.get(w.key)
          if (!task) return null
          return (
            <FakeWindow
              key={w.key}
              task={task}
              active={activeKey === w.key}
              zIndex={w.z}
              cascade={w.z}
              isNew={w.isNew}
              onFocus={(k) => { setActiveKey(k); setWindows((ws) => ws.map((x) => x.key === k ? { ...x, z: ++zCounter.current, isNew: false } : x)) }}
              onClose={closeWindow}
            />
          )
        })}
      </div>

      {/* ===== 圆形激活按钮(代替 Win+Tab 快捷键):无窗口时居中,有窗口时退到右下角 ===== */}
      {!overlayOpen && (
        <div
          className={`absolute pointer-events-none flex flex-col items-center ${
            windows.length === 0
              ? 'inset-0 justify-center'
              : 'right-10 bottom-20'
          }`}
          style={{ zIndex: 9999 }}
        >
          <button
            onClick={openOverlay}
            className="pointer-events-auto relative w-28 h-28 rounded-full flex flex-col items-center justify-center gap-1 cursor-pointer transition-transform duration-200 hover:scale-108 active:scale-95"
            style={{
              background:
                'linear-gradient(160deg, rgba(255,236,190,0.22), rgba(255,255,255,0.07) 40%, rgba(245,179,1,0.12))',
              border: '1px solid rgba(245,179,1,0.55)',
              backdropFilter: 'blur(20px)',
              WebkitBackdropFilter: 'blur(20px)',
              boxShadow:
                '0 12px 40px rgba(0,0,0,0.45), 0 0 32px rgba(245,179,1,0.18), inset 0 1px 0 rgba(255,236,190,0.4)',
              animation: 'orbIn 500ms cubic-bezier(0.22,1,0.36,1)',
            }}
          >
            {/* 脉冲光环 */}
            <span className="absolute inset-0 rounded-full border border-[#f5b301]/50" style={{ animation: 'pulseRing 2.4s ease-out infinite' }} />
            <span className="absolute inset-0 rounded-full border border-[#f5b301]/30" style={{ animation: 'pulseRing 2.4s ease-out infinite 1.2s' }} />
            <span className="text-[15px] font-semibold tracking-wide text-[#ffd97a] drop-shadow">Win + Tab</span>
            <span className="text-[10px] text-white/55">任务一览</span>
          </button>
          {windows.length === 0 && (
            <div className="mt-5 text-[13px] text-white/55 tracking-wide">
              点击按钮,模拟按下 Win + Tab
            </div>
          )}
        </div>
      )}

      {/* ===== 任务一览覆盖层:立即显示,无入场动画 ===== */}
      {overlayOpen && (
        <div
          className="absolute inset-0 flex flex-col items-center justify-center gap-7"
          style={{
            zIndex: 10000,
            background:
              'radial-gradient(90% 70% at 50% 42%, rgba(245,179,1,0.07), transparent 60%),' +
              'rgba(16, 19, 26, 0.5)',
            backdropFilter: 'blur(52px) saturate(160%) brightness(0.92)',
            WebkitBackdropFilter: 'blur(52px) saturate(160%) brightness(0.92)',
          }}
          onClick={(e) => { if (e.target === e.currentTarget) closeOverlay() }}
        >
          {/* 顶部提示 */}
          <div className="absolute top-8 flex items-center gap-2.5 text-[13px] text-white/55 tracking-[0.25em]">
            <span className="inline-block w-8 h-px bg-gradient-to-r from-transparent to-[#f5b301]/70" />
            点击六边形,或按下对应字母切换窗口
            <span className="inline-block w-8 h-px bg-gradient-to-l from-transparent to-[#f5b301]/70" />
          </div>

          {/* 丰巢六边形网格 */}
          <Hive
            running={running}
            searching={searching}
            scale={hiveScale}
            onSelect={switchTo}
          />

          {/* 空格键长条 + 搜索列表 */}
          <SearchPanel
            searching={searching}
            query={query}
            setQuery={setQuery}
            results={results}
            runningKeys={runningKeys}
            highlight={highlight}
            setHighlight={setHighlight}
            onSelect={switchTo}
            onEnter={enterSearch}
          />

          {/* 底部提示 */}
          <div className="absolute bottom-7 flex items-center gap-5 text-[12px] text-white/40">
            <span className="flex items-center gap-1.5"><kbd className="px-1.5 py-0.5 rounded border border-[#f5b301]/35 bg-[#f5b301]/8 text-[#ffd97a]/80">A</kbd>~<kbd className="px-1.5 py-0.5 rounded border border-[#f5b301]/35 bg-[#f5b301]/8 text-[#ffd97a]/80">Z</kbd> 直达窗口</span>
            <span className="flex items-center gap-1.5"><kbd className="px-3 py-0.5 rounded border border-[#f5b301]/35 bg-[#f5b301]/8 text-[#ffd97a]/80">空格</kbd> 搜索</span>
            <span className="flex items-center gap-1.5"><kbd className="px-1.5 py-0.5 rounded border border-[#f5b301]/35 bg-[#f5b301]/8 text-[#ffd97a]/80">Esc</kbd> {searching ? '退出搜索' : '关闭'}</span>
          </div>
        </div>
      )}
    </div>
  )
}
