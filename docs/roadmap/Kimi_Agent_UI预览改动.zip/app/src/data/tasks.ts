export type ThumbVariant =
  | 'notepad' | 'explorer' | 'browser' | 'code' | 'terminal'
  | 'mail' | 'paint' | 'settings' | 'video' | 'music'
  | 'calc' | 'doc' | 'sheet' | 'chat'

export interface TaskItem {
  key: string          // 键盘字母快捷键
  appName: string      // 应用名
  title: string        // 窗口标题(会被截断展示)
  variant: ThumbVariant
  accent: string       // 主题色
}

export const TASK_POOL: TaskItem[] = [
  { key: 'N', appName: '记事本',   title: 'WinTab产品规格v3.2 - 未保存 - 记事本', variant: 'notepad',  accent: '#5b9bd5' },
  { key: 'C', appName: 'VS Code',  title: 'hive.tsx — win-tab-launcher — Visual Studio Code', variant: 'code', accent: '#3c9cdd' },
  { key: 'E', appName: '资源管理器', title: 'D:\\Projects\\hive-launcher\\src\\components', variant: 'explorer', accent: '#f2c94c' },
  { key: 'B', appName: '浏览器',   title: 'Hexagon tiling with CSS clip-path — Stack Overflow', variant: 'browser', accent: '#4caf7d' },
  { key: 'T', appName: '终端',     title: 'Windows PowerShell — npm run dev', variant: 'terminal', accent: '#9aa0a6' },
  { key: 'M', appName: '邮件',     title: '收件箱 (23) — 产品评审会议纪要 - Outlook', variant: 'mail', accent: '#2f80ed' },
  { key: 'P', appName: '画图',     title: '丰巢布局草图_最终版_真的最终.png - 画图', variant: 'paint', accent: '#e06c9f' },
  { key: 'S', appName: '设置',     title: '设置 — 系统 > 显示 > 缩放与布局', variant: 'settings', accent: '#7c83fd' },
  { key: 'V', appName: '视频',     title: '新品发布会回放 2026 - 电影和电视', variant: 'video', accent: '#bb6bd9' },
  { key: 'L', appName: '音乐',     title: 'Lo-Fi 深夜专注歌单 — 正在播放', variant: 'music', accent: '#f2994a' },
  { key: 'K', appName: '计算器',   title: '计算器 — 标准模式', variant: 'calc', accent: '#56ccf2' },
  { key: 'W', appName: 'Word',     title: 'Q3_OKR_终稿_改_v7_final_真的不改了.docx', variant: 'doc', accent: '#2b579a' },
  { key: 'X', appName: 'Excel',    title: '预算明细_2026H2_汇总表.xlsx', variant: 'sheet', accent: '#217346' },
  { key: 'G', appName: '团队聊天', title: '产品一群 (99+) — 今晚发版吗?', variant: 'chat', accent: '#27ae60' },
]

export const KEY_ROWS: string[][] = [
  ['Q','W','E','R','T','Y','U','I','O','P'],
  ['A','S','D','F','G','H','J','K','L'],
  ['Z','X','C','V','B','N','M'],
]

/** 六边形几何参数(design 坐标系,单位 px) */
export const HEX_W = 132
export const HEX_H = 152
export const PITCH_X = HEX_W + 10       // 水平间距
export const PITCH_Y = HEX_H * 0.75 + 10 // 垂直间距(尖顶六边形行嵌套)
export const ROW_OFFSET = [0, PITCH_X * 0.5, PITCH_X * 1.0] // 仿键盘错位
export const GRID_W = PITCH_X * 9 + HEX_W
export const GRID_H = PITCH_Y * 2 + HEX_H

export function cellCenter(row: number, col: number) {
  return {
    x: ROW_OFFSET[row] + col * PITCH_X + HEX_W / 2,
    y: row * PITCH_Y + HEX_H / 2,
  }
}

/** G / H 之间的切割线 x 坐标 */
export const CUT_X = (() => {
  const g = cellCenter(1, 4).x // G
  const h = cellCenter(1, 5).x // H
  return (g + h) / 2
})()
